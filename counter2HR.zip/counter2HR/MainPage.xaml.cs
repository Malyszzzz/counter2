﻿namespace CounterApp;

public partial class MainPage : ContentPage
{
    private int CounterValue = 0;
    public MainPage()
    {
        InitializeComponent();
    }

    private void IncreaseCounter(object sender, EventArgs e)
    {
        CounterValue++; 
        CounterLabel.Text = CounterValue.ToString();
        UpdateBackground();
    }

    private void DecreaseCounter(object sender, EventArgs e)
    {
        CounterValue--;
        CounterLabel.Text = CounterValue.ToString(); 
        UpdateBackground();
    }

    private void UpdateBackground() //[rzepraszam, to bylo silniejsze ode mnie
    {
        if (CounterValue == -2137)
        {
            this.BackgroundImageSource = "ejp2.jpg"; 
        }
        else if (CounterValue == 2137)
        {
            this.BackgroundImageSource = "jp2.jpg";
        }
        else
        {
            this.BackgroundImageSource = null; 
        }
    }
}